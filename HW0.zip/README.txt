Export entire HW0 directory. 
Report is contained within the Hupka_HW0_Report.pdf file
All input images are included within the randomResNetPics or horsepics directory.
All output accuracies and output images (resnetgen) are within the outputs folder.
Run "hw0p#.py" with python3 or higher, modify image selection in desired problem by modifying "Image.open("XXXX/XXXX") line to desired image within "randomResNetPics" or "horsepics" 
relative to problem being ran.