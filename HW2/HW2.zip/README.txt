Each of the specified problems have been answered within the hw2.py file. Similarly, there is an explanation of the various data within the "Hupka_HW2_Report.pdf" file.
Ensure directory configuration is spared as HW2/rgbPics/"XXX" where "XXX" are the images that were used
To run: "python3 hw2.py" within the HW2 directory.
